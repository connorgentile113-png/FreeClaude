const SERVER = 'http://localhost:3210';
let claudeTabId = null;
let isConnected = false;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CONNECT') { connectToServer().then(ok => sendResponse({ ok })); return true; }
  if (message.type === 'GET_STATUS') { sendResponse({ connected: isConnected }); return true; }
  if (['RESPONSE_CHUNK','RESPONSE_DONE','RESPONSE_ERROR'].includes(message.type)) {
    forwardToServer(message);
    chrome.runtime.sendMessage(message).catch(() => {});
  }
});

async function connectToServer() {
  try {
    await ensureClaudeTab();
    startSSE();
    isConnected = true;
    chrome.action.setBadgeText({ text: '●' });
    chrome.action.setBadgeBackgroundColor({ color: '#c4a882' });
    return true;
  } catch(e) { return false; }
}

function startSSE() {
  const loop = async () => {
    try {
      const res = await fetch(`${SERVER}/extension-listen`, { headers: { Accept: 'text/event-stream' } });
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value);
        const lines = buf.split('\n');
        buf = lines.pop();
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          try {
            const d = JSON.parse(line.slice(6));
            if (d.type === 'prompt') await handlePrompt(d.prompt);
          } catch {}
        }
      }
    } catch(e) { isConnected = false; }
    setTimeout(loop, 3000);
  };
  loop();
}

async function handlePrompt(prompt) {
  await ensureClaudeTab();
  await sleep(500);
  await injectFresh();
  await sleep(500);
  await chrome.tabs.sendMessage(claudeTabId, { type: 'INJECT_PROMPT', prompt });
}

async function injectFresh() {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: claudeTabId },
      func: () => { delete window.__fc; }
    });
  } catch {}
  await chrome.scripting.executeScript({ target: { tabId: claudeTabId }, files: ['content.js'] });
}

async function ensureClaudeTab() {
  if (claudeTabId) {
    try {
      const t = await chrome.tabs.get(claudeTabId);
      if (t?.url?.includes('claude.ai') && !t.url.includes('/login')) {
        await chrome.tabs.update(claudeTabId, { active: true });
        return;
      }
    } catch {}
  }
  const tabs = await chrome.tabs.query({ url: 'https://claude.ai/*' });
  const good = tabs.find(t => !t.url.includes('/login'));
  if (good) { claudeTabId = good.id; await chrome.tabs.update(claudeTabId, { active: true }); return; }
  const tab = await chrome.tabs.create({ url: 'https://claude.ai/new', active: true });
  claudeTabId = tab.id;
  await new Promise(resolve => {
    const fn = (id, info) => {
      if (id === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(fn);
        setTimeout(resolve, 1500);
      }
    };
    chrome.tabs.onUpdated.addListener(fn);
    setTimeout(resolve, 12000);
  });
}

async function forwardToServer(data) {
  try {
    await fetch(`${SERVER}/response`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
  } catch {}
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
