if (!window.__fc) {
  window.__fc = true;

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg.type === 'INJECT_PROMPT') { injectAndSubmit(msg.prompt); reply({ ok: true }); }
  });

  async function injectAndSubmit(prompt) {
    try {
      const p = window.location.pathname;
      if (!p.startsWith('/chat/') && p !== '/new') {
        window.location.href = 'https://claude.ai/new'; return;
      }
      const input = await waitFor('div[contenteditable="true"]', 8000);
      if (!input) { send('RESPONSE_ERROR', { error: 'No input found. Logged in?' }); return; }

      input.focus();
      await sleep(100);
      input.innerHTML = '';
      document.execCommand('insertText', false, prompt);
      if (!input.textContent.trim()) {
        input.textContent = prompt;
        input.dispatchEvent(new InputEvent('input', { bubbles: true }));
      }
      await sleep(300);

      const btn = findSend();
      if (!btn) { send('RESPONSE_ERROR', { error: 'No send button found.' }); return; }

      const before = lastResponseText();
      btn.click();
      await pollResponse(before);
    } catch(e) {
      send('RESPONSE_ERROR', { error: e.message });
    }
  }

  function findSend() {
    for (const sel of ['button[aria-label="Send message"]','button[aria-label="Send Message"]','button[type="submit"]']) {
      const b = document.querySelector(sel);
      if (b && !b.disabled) return b;
    }
    return [...document.querySelectorAll('button')].find(b =>
      b.getAttribute('aria-label')?.toLowerCase().includes('send') && !b.disabled
    ) || null;
  }

  function lastResponseText() {
    const all = [...document.querySelectorAll('div[class*="font-claude-response"]')];
    const withText = all.filter(el => el.innerText.trim().length > 0);
    return withText.length ? withText[withText.length - 1].innerText.trim() : '';
  }

  async function pollResponse(before) {
    let last = '';
    let stable = 0;

    await new Promise(resolve => {
      const iv = setInterval(() => {
        const cur = lastResponseText();
        if (!cur || cur === before) return;

        if (cur !== last) {
          last = cur;
          stable = 0;
          send('RESPONSE_CHUNK', { text: cur });
        } else {
          stable++;
          if (stable >= 12 && !isTyping()) {
            clearInterval(iv);
            send('RESPONSE_DONE', { text: cur });
            resolve();
          }
        }
      }, 250);

      setTimeout(() => {
        clearInterval(iv);
        send('RESPONSE_DONE', { text: lastResponseText() || last || 'Timed out.' });
        resolve();
      }, 120000);
    });
  }

  function isTyping() {
    if (document.querySelector('button[aria-label="Stop"], button[aria-label="Stop generating"]')) return true;
    return !!document.querySelector('[data-is-streaming="true"]');
  }

  function send(type, data) {
    chrome.runtime.sendMessage({ type, ...data });
  }

  function waitFor(sel, timeout) {
    return new Promise(resolve => {
      const el = document.querySelector(sel);
      if (el) return resolve(el);
      const obs = new MutationObserver(() => {
        const found = document.querySelector(sel);
        if (found) { obs.disconnect(); resolve(found); }
      });
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(document.querySelector(sel)); }, timeout);
    });
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
}
