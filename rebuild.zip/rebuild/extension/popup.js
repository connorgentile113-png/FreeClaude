const messagesEl = document.getElementById('messages');
const emptyState = document.getElementById('emptyState');
const promptInput = document.getElementById('promptInput');
const sendBtn = document.getElementById('sendBtn');
const dot = document.getElementById('dot');
const statusText = document.getElementById('statusText');
const connectBtn = document.getElementById('connectBtn');
const openTab = document.getElementById('openTab');

let isWaiting = false;
let currentBubbleWrap = null;

chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => { if (res?.connected) setConnected(true); });

connectBtn.addEventListener('click', async () => {
  connectBtn.disabled = true;
  setStatus('working', 'Connecting...');
  const res = await chrome.runtime.sendMessage({ type: 'CONNECT' });
  if (res?.ok) { setConnected(true); }
  else {
    setStatus('error', 'Failed — is server running?');
    connectBtn.disabled = false;
    setTimeout(() => setStatus('idle', 'Not connected'), 3000);
  }
});

openTab.addEventListener('click', () => chrome.tabs.create({ url: 'https://claude.ai/new' }));

promptInput.addEventListener('input', () => {
  promptInput.style.height = 'auto';
  promptInput.style.height = Math.min(promptInput.scrollHeight, 90) + 'px';
  sendBtn.disabled = !promptInput.value.trim() || isWaiting;
});

promptInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!sendBtn.disabled) send(); }
});
sendBtn.addEventListener('click', send);

function send() {
  const prompt = promptInput.value.trim();
  if (!prompt || isWaiting) return;
  promptInput.value = ''; promptInput.style.height = 'auto';
  sendBtn.disabled = true; isWaiting = true;
  emptyState.style.display = 'none';
  appendMessage('user', prompt);
  currentBubbleWrap = appendTyping();
  setStatus('working', 'Sending...');
  chrome.runtime.sendMessage({ type: 'SEND_PROMPT', prompt }, (res) => {
    if (!res?.success) finishWithError(res?.error || 'Send failed');
    else setStatus('working', 'Waiting for Claude...');
  });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'RESPONSE_CHUNK') { updateBubble(msg.text); setStatus('working', 'Responding...'); }
  if (msg.type === 'RESPONSE_DONE') { updateBubble(msg.text); finishOk(); }
  if (msg.type === 'RESPONSE_ERROR') { finishWithError(msg.error); }
});

function appendMessage(role, text) {
  const w = document.createElement('div'); w.className = `message ${role}`;
  const l = document.createElement('div'); l.className = 'lbl'; l.textContent = role === 'user' ? 'You' : 'Claude';
  const b = document.createElement('div'); b.className = 'bubble'; b.textContent = text;
  w.appendChild(l); w.appendChild(b); messagesEl.appendChild(w); scroll(); return b;
}

function appendTyping() {
  const w = document.createElement('div'); w.className = 'message claude';
  const l = document.createElement('div'); l.className = 'lbl'; l.textContent = 'Claude';
  const b = document.createElement('div'); b.className = 'bubble'; b.textContent = '...';
  w.appendChild(l); w.appendChild(b); messagesEl.appendChild(w); scroll(); return w;
}

function updateBubble(text) {
  if (!currentBubbleWrap) return;
  const b = currentBubbleWrap.querySelector('.bubble');
  if (b) { b.className = 'bubble'; b.textContent = text; } scroll();
}

function finishOk() {
  isWaiting = false; currentBubbleWrap = null;
  sendBtn.disabled = !promptInput.value.trim();
  setStatus('connected', 'Connected · Ready');
}

function finishWithError(err) {
  if (currentBubbleWrap) {
    const b = currentBubbleWrap.querySelector('.bubble');
    if (b) { b.className = 'bubble'; b.style.color = 'var(--red)'; b.textContent = '⚠ ' + err; }
  }
  isWaiting = false; currentBubbleWrap = null;
  sendBtn.disabled = !promptInput.value.trim();
  setStatus('error', 'Error'); setTimeout(() => setStatus('connected', 'Connected · Ready'), 3000);
}

function setConnected(v) {
  connectBtn.disabled = v; connectBtn.textContent = v ? 'Connected ✓' : 'Connect';
  setStatus(v ? 'connected' : 'idle', v ? 'Connected · Ready' : 'Not connected');
  if (v) sendBtn.disabled = false;
}

function setStatus(state, text) {
  dot.className = 'dot ' + (state === 'connected' ? 'connected' : state === 'working' ? 'working' : state === 'error' ? 'error' : '');
  statusText.textContent = text;
}

function scroll() { messagesEl.scrollTop = messagesEl.scrollHeight; }
