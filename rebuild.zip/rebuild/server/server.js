#!/usr/bin/env node
// FreeClaude bridge server — localhost:3210

const http = require('http');
const PORT = 3210;

let extensionRes = null;
let terminalRes = null;
let pendingPrompt = null;

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, CORS); res.end(); return; }

  if (req.method === 'GET' && req.url === '/extension-listen') {
    res.writeHead(200, { ...CORS, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    extensionRes = res;
    res.write('data: {"type":"connected"}\n\n');
    console.log('[server] Extension connected');
    if (pendingPrompt) { sendToExtension(pendingPrompt); pendingPrompt = null; }
    req.on('close', () => { extensionRes = null; console.log('[server] Extension disconnected'); });
    return;
  }

  if (req.method === 'GET' && req.url === '/terminal-listen') {
    res.writeHead(200, { ...CORS, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    terminalRes = res;
    res.write('data: {"type":"connected"}\n\n');
    req.on('close', () => { terminalRes = null; });
    return;
  }

  if (req.method === 'POST' && req.url === '/prompt') {
    let body = '';
    req.on('data', d => body += d);
    req.on('end', () => {
      try {
        const { prompt } = JSON.parse(body);
        console.log('[server] Got prompt:', prompt.slice(0, 80));
        if (extensionRes) { sendToExtension(prompt); }
        else { pendingPrompt = prompt; console.log('[server] Queued prompt'); }
        res.writeHead(200, { ...CORS, 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, queued: !extensionRes }));
      } catch (e) { res.writeHead(400, CORS); res.end(JSON.stringify({ error: e.message })); }
    });
    return;
  }

  if (req.method === 'POST' && req.url === '/response') {
    let body = '';
    req.on('data', d => body += d);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        if (terminalRes) terminalRes.write(`data: ${JSON.stringify(data)}\n\n`);
        res.writeHead(200, { ...CORS, 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true }));
      } catch (e) { res.writeHead(400, CORS); res.end(JSON.stringify({ error: e.message })); }
    });
    return;
  }

  if (req.method === 'GET' && req.url === '/ping') {
    res.writeHead(200, { ...CORS, 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, extensionConnected: !!extensionRes }));
    return;
  }

  res.writeHead(404, CORS); res.end('Not found');
});

function sendToExtension(prompt) {
  if (extensionRes) extensionRes.write(`data: ${JSON.stringify({ type: 'prompt', prompt })}\n\n`);
}

server.listen(PORT, '127.0.0.1', () => {
  console.log(`\n🟠 FreeClaude server running on http://localhost:${PORT}\n`);
});
