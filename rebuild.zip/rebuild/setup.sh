#!/usr/bin/env bash
set -e

INSTALL_DIR="$HOME/freeclaude"
BIN_DIR="$HOME/.local/bin"
DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "🟠 FreeClaude Setup"
echo "─────────────────────────────────────────"

# Install files
echo "→ Installing to $INSTALL_DIR"
mkdir -p "$INSTALL_DIR/extension" "$INSTALL_DIR/server"

cp "$DIR/server/server.js" "$INSTALL_DIR/server/server.js"
cp "$DIR/freeclaude-skill.md" "$INSTALL_DIR/freeclaude-skill.md"

for f in manifest.json background.js content.js popup.html popup.js icon16.png icon48.png icon128.png; do
  [ -f "$DIR/extension/$f" ] && cp "$DIR/extension/$f" "$INSTALL_DIR/extension/$f"
done

# Install CLI
mkdir -p "$BIN_DIR"
cp "$DIR/bin/freeclaude" "$BIN_DIR/freeclaude"
chmod +x "$BIN_DIR/freeclaude"

# Add to PATH
RC="$HOME/.bash_profile"
[[ "$SHELL" == *zsh* ]] && RC="$HOME/.zshrc"
if ! grep -q "\.local/bin" "$RC" 2>/dev/null; then
  echo '' >> "$RC"
  echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$RC"
  echo "→ Added ~/.local/bin to PATH in $RC"
fi
export PATH="$BIN_DIR:$PATH"

# Start server
echo "→ Starting server on localhost:3210..."
pkill -f "node.*server.js" 2>/dev/null || true
sleep 0.3
nohup node "$INSTALL_DIR/server/server.js" > "$INSTALL_DIR/server.log" 2>&1 &
echo "→ Server started (PID $!)"

echo ""
echo "✅ Done! Next steps:"
echo ""
echo "  1. Load Chrome extension:"
echo "     chrome://extensions → Developer Mode → Load unpacked → $INSTALL_DIR/extension"
echo ""
echo "  2. Open new terminal and type: freeclaude"
echo ""
echo "  3. Click the FC icon in Chrome to connect."
echo ""
